// Armory shop UI: category tabs + stat bars computed from the game's real weapon values
(function(){
const $=i=>document.getElementById(i);
const shop=$('modal-shop');if(!shop)return;
// real values from the game's weapon table (damage, pellets, fireRate s, magSize, reloadTime s, range)
const W={desert_eagle:[54,1,.35,7,1.5,120],m1887:[24,8,.22,2,1.8,45],mp40:[22,1,.085,30,2,75],ak47:[38,1,.13,30,2.2,150],awm:[150,1,1.3,5,2.6,300]};
const bars=w=>({DMG:Math.min(100,100*Math.sqrt(w[0]*w[1]/192)),RANGE:100*w[5]/300,RATE:Math.min(100,100*.085/w[2]),MAG:Math.min(100,100*w[3]/30),RELOAD:Math.min(100,100*1.5/w[4])});
shop.querySelectorAll('.shop-item').forEach(it=>{const w=W[it.dataset.item];if(!w||it.querySelector('.sbars'))return;
  const b=bars(w),d=document.createElement('div');d.className='sbars';
  d.innerHTML=Object.entries(b).map(([k,v])=>`<div class="sbar">${k}<i><b style="width:${Math.round(v)}%"></b></i></div>`).join('');
  it.querySelector('.item-stat').after(d)});
const cats=[...shop.querySelectorAll('.shop-category')],body=shop.querySelector('.shop-body');
const names=['PISTOLS','SMG / SHOTGUN','RIFLE / SNIPER','ARMOR / UTILITY'];
const tabs=document.createElement('div');tabs.className='shop-tabs';
tabs.innerHTML='<button class="shop-tab on" data-i="all" type="button">ALL</button>'+cats.map((c,i)=>`<button class="shop-tab" data-i="${i}" type="button">${names[i]||c.querySelector('h3').textContent}</button>`).join('');
body.before(tabs);
tabs.onclick=e=>{const b=e.target.closest('.shop-tab');if(!b)return;
  tabs.querySelectorAll('.shop-tab').forEach(x=>x.classList.toggle('on',x===b));
  cats.forEach((c,i)=>c.classList.toggle('hide',b.dataset.i!=='all'&&+b.dataset.i!==i))};
})();
